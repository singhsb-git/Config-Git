package com.city.connectivity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityConnectivityApplicationTests {

	@Test
	void contextLoads() {
	}

}